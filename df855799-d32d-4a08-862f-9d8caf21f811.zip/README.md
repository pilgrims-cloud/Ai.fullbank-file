# Global Bank Nigeria - Banking System

A comprehensive banking management system with admin and customer portals.

## 🏦 Features

### Admin Portal
- **Cover Page**: Professional landing page with bank information
- **Secure Login**: Username/password authentication with AGB code (8 digits + 1 letter)
- **Dashboard Overview**: Real-time statistics and account management
- **Customer Management**:
  - Create new customer accounts
  - Edit customer profiles (name, phone, email, bank, account type)
  - Credit/Debit balance adjustments
  - Approve/Block/Activate accounts
  - Delete accounts
- **KYC Verification**:
  - Verify customer documents
  - Manage ID information (National ID, Passport, Driver's License, Voter's Card)
  - BVN verification
  - KYC status tracking (Pending, Verified, Rejected)
- **Transaction Monitoring**: View all transactions with terminal logs

### Customer Wallet
- **Secure Login**: Account number + AGB code authentication
- **Balance Management**: View account balance and details
- **Money Transfers**:
  - Internal Transfer (Same Bank)
  - External Bank Transfer (Other Nigerian Banks)
  - Wallet Transfer (Digital Wallets)
- **Transaction History**: Complete transaction records with type indicators

## 📁 Project Structure

```
/workspace/
├── admin/                  # Admin portal source files
│   ├── cover.html         # Cover page
│   ├── login.html         # Admin login with AGB code
│   └── dashboard.html     # Admin dashboard (obfuscated)
├── customer/              # Customer wallet source
│   └── index.html         # Customer wallet interface
├── backend/               # Node.js backend
│   ├── server.js          # Express server with all APIs
│   ├── package.json       # Dependencies
│   └── data/              # Data storage (auto-created)
│       ├── accounts.json  # Customer accounts
│       ├── transactions.json # Transaction records
│       └── admin.json     # Admin credentials
├── public/                # Static files (served by backend)
│   ├── admin/
│   └── customer/
└── logs/                  # System logs
```

## 🚀 Getting Started

### Prerequisites
- Node.js (v14 or higher)
- npm (Node Package Manager)

### Installation

1. **Install Backend Dependencies**:
   ```bash
   cd backend
   npm install
   ```

2. **Start the Backend Server**:
   ```bash
   npm start
   ```
   
   The server will start on `http://localhost:3000`

### Access Points

Once the server is running:

- **Admin Portal**: http://localhost:3000/admin/cover.html
- **Customer Wallet**: http://localhost:3000/customer/

## 🔐 Default Credentials

### Admin Login
- **Username**: `admin`
- **Password**: `admin123`
- **Note**: Change these credentials in `backend/data/admin.json` for production

### Customer Login
- Use account number and AGB code created by admin
- New accounts start with status "pending" - admin must approve them

## 📋 AGB Code System

Each customer account gets a unique AGB Code:
- **Format**: 8 digits + 1 letter (e.g., 12345678A)
- **Purpose**: Additional security for customer login
- **Generation**: Auto-generated when admin creates account

## 💳 Transaction Types

### 1. Internal Transfer
- Transfer between accounts within Global Bank Nigeria
- Instant processing
- Supports NGN and USD

### 2. External Bank Transfer
- Transfer to other Nigerian banks
- Supported banks: Access Bank, First Bank, GTBank, UBA, Zenith Bank, Wema Bank, Sterling Bank, Fidelity Bank
- Real-time processing

### 3. Wallet Transfer
- Transfer to digital wallets
- Enter wallet address as receiver
- Supports all currencies

## 🔧 API Endpoints

### Authentication
- `POST /login` - Admin login

### Accounts
- `GET /accounts` - Get all accounts
- `POST /accounts` - Create account
- `GET /accounts/:accountNumber` - Get specific account
- `PUT /accounts/:accountNumber` - Update account
- `DELETE /accounts/:accountNumber` - Delete account

### Transactions
- `GET /transactions` - Get all transactions
- `POST /transactions` - Create transaction
- `GET /transactions/:accountNumber` - Get account transactions

### System
- `GET /stats` - Get system statistics
- `GET /health` - Health check

## 🛡️ Security Features

1. **Obfuscated Admin Code**: Admin dashboard JavaScript is obfuscated for security
2. **AGB Code Authentication**: Two-factor authentication for customers
3. **Status-Based Access**: Only approved accounts can perform transactions
4. **KYC Verification**: Multi-level KYC system with document management
5. **Transaction Validation**: Comprehensive validation for all transfers

## 📊 Bank Information

- **Owner**: Olawale Abdul-Ganiyu
- **Contact**: adeganglobal@gmail.com
- **CBN Number**: Agb999
- **SWIFT Code**: GBNNGLNA
- **BIN**: 123456

## 🎨 Features Implemented

### Admin Portal ✅
- [x] Professional cover page
- [x] AGB code generation (8 digits + 1 letter)
- [x] Customer account creation
- [x] Balance editing (Credit/Debit/Set)
- [x] Profile management
- [x] KYC verification system
- [x] Document upload support
- [x] Approve/Block/Activate functionality
- [x] Account deletion
- [x] Transaction monitoring
- [x] Terminal logs
- [x] Quick statistics dashboard
- [x] Obfuscated JavaScript

### Customer Wallet ✅
- [x] Secure login with AGB code
- [x] Balance display
- [x] Internal transfers
- [x] External bank transfers
- [x] Wallet transfers
- [x] Transaction history
- [x] KYC status display
- [x] Session persistence

### Backend ✅
- [x] Express server setup
- [x] JSON data persistence
- [x] RESTful API endpoints
- [x] CORS enabled
- [x] Transaction validation
- [x] Account management
- [x] Statistics endpoint

## 📝 Notes

- All data is stored in JSON files in `backend/data/`
- The system uses in-memory data with file persistence
- For production, consider using a proper database (PostgreSQL, MongoDB)
- The obfuscated admin code can be viewed by the owner for editing
- Document uploads are handled in the KYC modal (requires file storage configuration)

## 🔧 Troubleshooting

### Server won't start
- Check if port 3000 is already in use
- Ensure Node.js is installed: `node --version`
- Check logs in `logs/` directory

### Can't access admin portal
- Ensure backend server is running
- Check browser console for errors
- Verify admin credentials in `backend/data/admin.json`

### Transactions not working
- Ensure both sender and receiver accounts are approved
- Check for sufficient balance
- Verify currency matches for internal transfers

## 📞 Support

For issues or questions, contact: adeganglobal@gmail.com

---

**Global Bank Nigeria** - Owner: Olawale Abdul-Ganiyu  
Built with ❤️ using Node.js, Express, and modern web technologies