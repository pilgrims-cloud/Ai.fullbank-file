# 🚀 Quick Start Guide - Global Bank Nigeria

## 🎯 You're All Set! The system is running and tested.

### 📱 Access Your Banking System

The backend server is **already running** on `http://localhost:3000`

#### Admin Portal Access
1. **Cover Page**: http://localhost:3000/admin/cover.html
2. **Login**: http://localhost:3000/admin/login.html
   - Username: `admin`
   - Password: `admin123`
3. **Dashboard**: http://localhost:3000/admin/dashboard.html

#### Customer Wallet Access
1. **Customer Portal**: http://localhost:3000/customer/

## 🏦 What You Can Do

### As Admin
1. **Login** using admin credentials
2. **Create Customer Accounts** with auto-generated AGB codes (8 digits + 1 letter)
3. **Manage Balances** - Credit, Debit, or Set account balances
4. **Edit Profiles** - Update customer information
5. **KYC Verification** - Verify documents and approve customers
6. **Approve/Block/Activate** accounts
7. **Monitor Transactions** - View all transfers in real-time
8. **Delete Accounts** - Remove customers when needed

### As Customer
1. **Login** with Account Number + AGB Code
2. **View Balance** and account details
3. **Send Money** via:
   - ✅ Internal Transfer (Same Bank)
   - ✅ External Bank Transfer (Other Nigerian Banks)
   - ✅ Wallet Transfer (Digital Wallets)
4. **View Transaction History** with all details

## 📋 Test Account Created

A test account has been created for you:
- **Account Number**: 1234567890
- **AGB Code**: 98765432B
- **Balance**: ₦1,000.00
- **Status**: Approved

Use this to test the customer wallet!

## 🔧 Server Management

### Restart Server (if needed)
```bash
cd backend
npm start
```

### Stop Server
Find the process and kill it, or press Ctrl+C in the terminal

### View Logs
```bash
tail -f /workspace/outputs/workspace_output_*.txt
```

## 📊 Data Storage

All data is stored in `backend/data/`:
- `accounts.json` - All customer accounts
- `transactions.json` - Transaction history
- `admin.json` - Admin credentials

## 🔒 Security Features

✅ **AGB Code System** - 8 digits + 1 letter for each customer
✅ **Obfuscated Admin Code** - Protected JavaScript
✅ **Status-Based Access** - Only approved accounts can transact
✅ **KYC Verification** - Multi-level verification system
✅ **Transaction Validation** - Comprehensive checks

## 🎨 Key Features Implemented

### Admin Dashboard ✅
- Professional cover page with bank info
- AGB code generation for each customer
- Balance editing (Credit/Debit/Set)
- Profile management
- KYC verification with document upload
- Approve/Block/Activate functionality
- Account deletion
- Real-time transaction monitoring
- Terminal logs
- Quick statistics
- Obfuscated JavaScript code

### Customer Wallet ✅
- Secure login with AGB code
- Beautiful balance display
- Internal transfers (same bank)
- External transfers (other Nigerian banks)
- Wallet transfers (digital wallets)
- Complete transaction history
- KYC status display
- Session persistence

## 📞 Support

- **Owner**: Olawale Abdul-Ganiyu
- **Email**: adeganglobal@gmail.com
- **CBN Number**: Agb999
- **SWIFT**: GBNNGLNA

## 🎉 Start Using Your Banking System Now!

1. Open http://localhost:3000/admin/cover.html
2. Login with admin/admin123
3. Create customer accounts
4. Approve accounts for customers
5. Customers can login and start transacting!

---

**Built with ❤️ for Global Bank Nigeria**