const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '../public')));

// Data storage files
const ACCOUNTS_FILE = path.join(__dirname, '../data/accounts.json');
const TRANSACTIONS_FILE = path.join(__dirname, '../data/transactions.json');
const ADMIN_FILE = path.join(__dirname, '../data/admin.json');

// Ensure data directory exists
const dataDir = path.join(__dirname, '../data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Initialize data files
function initializeDataFiles() {
  // Initialize accounts
  if (!fs.existsSync(ACCOUNTS_FILE)) {
    fs.writeFileSync(ACCOUNTS_FILE, JSON.stringify([]));
  }
  
  // Initialize transactions
  if (!fs.existsSync(TRANSACTIONS_FILE)) {
    fs.writeFileSync(TRANSACTIONS_FILE, JSON.stringify([]));
  }
  
  // Initialize admin credentials
  if (!fs.existsSync(ADMIN_FILE)) {
    const adminData = {
      username: 'admin',
      password: 'admin123', // Change this in production
      agbCode: '12345678A' // Default AGB code
    };
    fs.writeFileSync(ADMIN_FILE, JSON.stringify(adminData));
  }
}

// Helper functions to read/write data
function readAccounts() {
  const data = fs.readFileSync(ACCOUNTS_FILE, 'utf8');
  return JSON.parse(data);
}

function writeAccounts(accounts) {
  fs.writeFileSync(ACCOUNTS_FILE, JSON.stringify(accounts, null, 2));
}

function readTransactions() {
  const data = fs.readFileSync(TRANSACTIONS_FILE, 'utf8');
  return JSON.parse(data);
}

function writeTransactions(transactions) {
  fs.writeFileSync(TRANSACTIONS_FILE, JSON.stringify(transactions, null, 2));
}

function readAdmin() {
  const data = fs.readFileSync(ADMIN_FILE, 'utf8');
  return JSON.parse(data);
}

// API Routes

// Admin Login
app.post('/login', (req, res) => {
  try {
    const { username, password, agbCode } = req.body;
    const admin = readAdmin();
    
    if (username === admin.username && password === admin.password) {
      // Generate simple token (in production, use JWT)
      const token = Buffer.from(`${username}-${Date.now()}`).toString('base64');
      
      res.json({
        success: true,
        token,
        message: 'Login successful'
      });
    } else {
      res.json({
        success: false,
        message: 'Invalid credentials'
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get all accounts
app.get('/accounts', (req, res) => {
  try {
    const accounts = readAccounts();
    res.json(accounts);
  } catch (error) {
    res.status(500).json({ error: 'Error reading accounts' });
  }
});

// Create account
app.post('/accounts', (req, res) => {
  try {
    const accounts = readAccounts();
    const newAccount = {
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    accounts.push(newAccount);
    writeAccounts(accounts);
    
    res.json({ success: true, account: newAccount });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error creating account' });
  }
});

// Update account
app.put('/accounts/:accountNumber', (req, res) => {
  try {
    const { accountNumber } = req.params;
    const accounts = readAccounts();
    const accountIndex = accounts.findIndex(a => a.accountNumber === accountNumber);
    
    if (accountIndex === -1) {
      return res.status(404).json({ success: false, message: 'Account not found' });
    }
    
    // Update only provided fields
    accounts[accountIndex] = {
      ...accounts[accountIndex],
      ...req.body,
      updatedAt: new Date().toISOString()
    };
    
    writeAccounts(accounts);
    res.json({ success: true, account: accounts[accountIndex] });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error updating account' });
  }
});

// Delete account
app.delete('/accounts/:accountNumber', (req, res) => {
  try {
    const { accountNumber } = req.params;
    const accounts = readAccounts();
    const accountIndex = accounts.findIndex(a => a.accountNumber === accountNumber);
    
    if (accountIndex === -1) {
      return res.status(404).json({ success: false, message: 'Account not found' });
    }
    
    accounts.splice(accountIndex, 1);
    writeAccounts(accounts);
    
    res.json({ success: true, message: 'Account deleted' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error deleting account' });
  }
});

// Get specific account
app.get('/accounts/:accountNumber', (req, res) => {
  try {
    const { accountNumber } = req.params;
    const accounts = readAccounts();
    const account = accounts.find(a => a.accountNumber === accountNumber);
    
    if (!account) {
      return res.status(404).json({ success: false, message: 'Account not found' });
    }
    
    res.json(account);
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error reading account' });
  }
});

// Get all transactions
app.get('/transactions', (req, res) => {
  try {
    const transactions = readTransactions();
    // Sort by date descending (newest first)
    transactions.sort((a, b) => new Date(b.dateTime) - new Date(a.dateTime));
    res.json(transactions);
  } catch (error) {
    res.status(500).json({ error: 'Error reading transactions' });
  }
});

// Create transaction
app.post('/transactions', (req, res) => {
  try {
    const transactions = readTransactions();
    const newTransaction = {
      id: Date.now(),
      ...req.body,
      createdAt: new Date().toISOString()
    };
    
    transactions.push(newTransaction);
    writeTransactions(transactions);
    
    res.json({ success: true, transaction: newTransaction });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error creating transaction' });
  }
});

// Get transactions for specific account
app.get('/transactions/:accountNumber', (req, res) => {
  try {
    const { accountNumber } = req.params;
    const transactions = readTransactions();
    const accountTransactions = transactions.filter(
      t => t.senderAccount === accountNumber || t.receiverAccount === accountNumber
    );
    
    // Sort by date descending
    accountTransactions.sort((a, b) => new Date(b.dateTime) - new Date(a.dateTime));
    
    res.json(accountTransactions);
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error reading transactions' });
  }
});

// Get system statistics
app.get('/stats', (req, res) => {
  try {
    const accounts = readAccounts();
    const transactions = readTransactions();
    
    const totalAccounts = accounts.length;
    const activeAccounts = accounts.filter(a => a.status === 'approved').length;
    const pendingKYC = accounts.filter(a => a.kycStatus === 'pending').length;
    const totalBalance = accounts.reduce((sum, a) => sum + (a.balance || 0), 0);
    const totalTransactions = transactions.length;
    
    res.json({
      totalAccounts,
      activeAccounts,
      pendingKYC,
      totalBalance,
      totalTransactions
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error reading stats' });
  }
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', message: 'Global Bank Backend is running' });
});

// Initialize and start server
initializeDataFiles();

app.listen(PORT, () => {
  console.log('=================================');
  console.log('🏦 Global Bank Nigeria Backend');
  console.log('=================================');
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`Admin: http://localhost:${PORT}/admin/cover.html`);
  console.log(`Customer: http://localhost:${PORT}/customer/`);
  console.log('=================================');
  console.log('Default Admin Credentials:');
  console.log('Username: admin');
  console.log('Password: admin123');
  console.log('=================================');
});

module.exports = app;