const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const multer = require('multer');

const app = express();
const PORT = 3000;

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = path.join(__dirname, '../uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Data storage files
const ACCOUNTS_FILE = path.join(__dirname, '../data/accounts.json');
const TRANSACTIONS_FILE = path.join(__dirname, '../data/transactions.json');
const ADMIN_FILE = path.join(__dirname, '../data/admin.json');
const NOTIFICATIONS_FILE = path.join(__dirname, '../data/notifications.json');

// Ensure data directory exists
const dataDir = path.join(__dirname, '../data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Initialize data files
function initializeDataFiles() {
  if (!fs.existsSync(ACCOUNTS_FILE)) {
    fs.writeFileSync(ACCOUNTS_FILE, JSON.stringify([]));
  }
  
  if (!fs.existsSync(TRANSACTIONS_FILE)) {
    fs.writeFileSync(TRANSACTIONS_FILE, JSON.stringify([]));
  }
  
  if (!fs.existsSync(ADMIN_FILE)) {
    const adminData = {
      username: 'admin',
      password: 'admin123',
      agbCode: '12345678A',
      email: 'adeganglobal@gmail.com',
      phone: '+234XXXXXXXXXX'
    };
    fs.writeFileSync(ADMIN_FILE, JSON.stringify(adminData));
  }
  
  if (!fs.existsSync(NOTIFICATIONS_FILE)) {
    fs.writeFileSync(NOTIFICATIONS_FILE, JSON.stringify([]));
  }
}

// Helper functions
function readAccounts() {
  try {
    const data = fs.readFileSync(ACCOUNTS_FILE, 'utf8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

function writeAccounts(accounts) {
  fs.writeFileSync(ACCOUNTS_FILE, JSON.stringify(accounts, null, 2));
}

function readTransactions() {
  try {
    const data = fs.readFileSync(TRANSACTIONS_FILE, 'utf8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

function writeTransactions(transactions) {
  fs.writeFileSync(TRANSACTIONS_FILE, JSON.stringify(transactions, null, 2));
}

function readAdmin() {
  try {
    const data = fs.readFileSync(ADMIN_FILE, 'utf8');
    return JSON.parse(data);
  } catch {
    return null;
  }
}

function readNotifications() {
  try {
    const data = fs.readFileSync(NOTIFICATIONS_FILE, 'utf8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

function writeNotifications(notifications) {
  fs.writeFileSync(NOTIFICATIONS_FILE, JSON.stringify(notifications, null, 2));
}

// Nigerian Banks List
const NIGERIAN_BANKS = [
  "Access Bank",
  "Citibank",
  "Diamond Bank",
  "Ecobank Nigeria",
  "Fidelity Bank",
  "First Bank of Nigeria",
  "First City Monument Bank (FCMB)",
  "Guaranty Trust Bank (GTBank)",
  "Heritage Bank",
  "Jaiz Bank",
  "Keystone Bank",
  "Polaris Bank",
  "Providus Bank",
  "Stanbic IBTC Bank",
  "Standard Chartered Bank",
  "Sterling Bank",
  "SunTrust Bank",
  "Union Bank of Nigeria",
  "United Bank for Africa (UBA)",
  "Unity Bank",
  "Wema Bank",
  "Zenith Bank",
  "TajBank",
  "Globus Bank"
];

// API Routes

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', message: 'Global Bank Backend is running' });
});

// Get Nigerian banks
app.get('/banks', (req, res) => {
  res.json({ banks: NIGERIAN_BANKS });
});

// Admin Login
app.post('/login', (req, res) => {
  try {
    console.log('Login attempt:', req.body);
    const { username, password, agbCode } = req.body;
    const admin = readAdmin();
    
    if (!admin) {
      console.log('No admin found');
      return res.json({ success: false, message: 'Admin not configured' });
    }
    
    console.log('Comparing:', username, admin.username, password, admin.password);
    
    if (username === admin.username && password === admin.password) {
      const token = Buffer.from(`${username}-${Date.now()}`).toString('base64');
      
      console.log('Login successful');
      res.json({
        success: true,
        token,
        message: 'Login successful',
        admin: {
          username: admin.username,
          email: admin.email
        }
      });
    } else {
      console.log('Login failed');
      res.json({
        success: false,
        message: 'Invalid credentials'
      });
    }
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Contact Admin
app.post('/contact-admin', (req, res) => {
  try {
    const { name, email, phone, message } = req.body;
    
    // Simulate sending email
    console.log('Contact Admin Request:', { name, email, phone, message });
    
    res.json({ 
      success: true, 
      message: 'Message sent to admin successfully. We will respond shortly.' 
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error sending message' });
  }
});

// Forgot Password
app.post('/forgot-password', (req, res) => {
  try {
    const { accountNumber, email } = req.body;
    const accounts = readAccounts();
    const account = accounts.find(a => a.accountNumber === accountNumber && a.email === email);
    
    if (!account) {
      return res.json({ success: false, message: 'Account not found' });
    }
    
    // In production, send email with reset link
    console.log('Password reset request for:', accountNumber);
    
    res.json({ 
      success: true, 
      message: 'Password reset link sent to your email' 
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error processing request' });
  }
});

// Get all accounts
app.get('/accounts', (req, res) => {
  try {
    const accounts = readAccounts();
    res.json(accounts);
  } catch (error) {
    res.status(500).json({ error: 'Error reading accounts' });
  }
});

// Create account
app.post('/accounts', (req, res) => {
  try {
    console.log('Creating account:', req.body);
    const accounts = readAccounts();
    
    // Check if account number already exists
    if (accounts.find(a => a.accountNumber === req.body.accountNumber)) {
      return res.json({ success: false, message: 'Account number already exists' });
    }
    
    const newAccount = {
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    accounts.push(newAccount);
    writeAccounts(accounts);
    
    // Send notification
    const notifications = readNotifications();
    notifications.push({
      type: 'new_account',
      accountNumber: newAccount.accountNumber,
      message: `New account created: ${newAccount.name}`,
      timestamp: new Date().toISOString()
    });
    writeNotifications(notifications);
    
    console.log('Account created successfully');
    res.json({ success: true, account: newAccount });
  } catch (error) {
    console.error('Error creating account:', error);
    res.status(500).json({ success: false, message: 'Error creating account' });
  }
});

// Update account
app.put('/accounts/:accountNumber', (req, res) => {
  try {
    const { accountNumber } = req.params;
    const accounts = readAccounts();
    const accountIndex = accounts.findIndex(a => a.accountNumber === accountNumber);
    
    if (accountIndex === -1) {
      return res.status(404).json({ success: false, message: 'Account not found' });
    }
    
    accounts[accountIndex] = {
      ...accounts[accountIndex],
      ...req.body,
      updatedAt: new Date().toISOString()
    };
    
    writeAccounts(accounts);
    
    // Send notification for balance changes
    if (req.body.balance !== undefined) {
      const notifications = readNotifications();
      notifications.push({
        type: 'balance_change',
        accountNumber,
        message: `Balance updated for account ${accountNumber}`,
        timestamp: new Date().toISOString()
      });
      writeNotifications(notifications);
    }
    
    res.json({ success: true, account: accounts[accountIndex] });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error updating account' });
  }
});

// Delete account
app.delete('/accounts/:accountNumber', (req, res) => {
  try {
    const { accountNumber } = req.params;
    const accounts = readAccounts();
    const accountIndex = accounts.findIndex(a => a.accountNumber === accountNumber);
    
    if (accountIndex === -1) {
      return res.status(404).json({ success: false, message: 'Account not found' });
    }
    
    accounts.splice(accountIndex, 1);
    writeAccounts(accounts);
    
    res.json({ success: true, message: 'Account deleted' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error deleting account' });
  }
});

// Get specific account
app.get('/accounts/:accountNumber', (req, res) => {
  try {
    const { accountNumber } = req.params;
    const accounts = readAccounts();
    const account = accounts.find(a => a.accountNumber === accountNumber);
    
    if (!account) {
      return res.status(404).json({ success: false, message: 'Account not found' });
    }
    
    res.json(account);
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error reading account' });
  }
});

// Upload KYC document
app.post('/accounts/:accountNumber/upload-kyc', upload.single('document'), (req, res) => {
  try {
    const { accountNumber } = req.params;
    const { kycStatus, kycIdType, kycIdNumber, bvn, kycNotes } = req.body;
    
    const accounts = readAccounts();
    const accountIndex = accounts.findIndex(a => a.accountNumber === accountNumber);
    
    if (accountIndex === -1) {
      return res.status(404).json({ success: false, message: 'Account not found' });
    }
    
    const documentPath = req.file ? req.file.path : null;
    
    accounts[accountIndex] = {
      ...accounts[accountIndex],
      kycStatus: kycStatus || accounts[accountIndex].kycStatus,
      kycIdType,
      kycIdNumber,
      bvn,
      kycNotes,
      kycDocument: documentPath,
      kycDocumentName: req.file ? req.file.originalname : null,
      updatedAt: new Date().toISOString()
    };
    
    writeAccounts(accounts);
    
    res.json({ 
      success: true, 
      message: 'KYC document uploaded successfully',
      account: accounts[accountIndex]
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ success: false, message: 'Error uploading document' });
  }
});

// Get all transactions
app.get('/transactions', (req, res) => {
  try {
    const transactions = readTransactions();
    transactions.sort((a, b) => new Date(b.dateTime) - new Date(a.dateTime));
    res.json(transactions);
  } catch (error) {
    res.status(500).json({ error: 'Error reading transactions' });
  }
});

// Create transaction
app.post('/transactions', (req, res) => {
  try {
    console.log('Creating transaction:', req.body);
    const transactions = readTransactions();
    
    const newTransaction = {
      id: Date.now(),
      ...req.body,
      createdAt: new Date().toISOString()
    };
    
    transactions.push(newTransaction);
    writeTransactions(transactions);
    
    // Send notifications
    const notifications = readNotifications();
    
    // Notify sender
    notifications.push({
      type: 'transaction_sent',
      accountNumber: newTransaction.senderAccount,
      message: `You sent ${newTransaction.amount} ${newTransaction.currency} to ${newTransaction.receiverAccount}`,
      timestamp: new Date().toISOString()
    });
    
    // Notify receiver (if internal)
    if (newTransaction.type === 'internal') {
      notifications.push({
        type: 'transaction_received',
        accountNumber: newTransaction.receiverAccount,
        message: `You received ${newTransaction.amount} ${newTransaction.currency} from ${newTransaction.senderAccount}`,
        timestamp: new Date().toISOString()
      });
    }
    
    writeNotifications(notifications);
    
    console.log('Transaction created successfully');
    res.json({ success: true, transaction: newTransaction });
  } catch (error) {
    console.error('Error creating transaction:', error);
    res.status(500).json({ success: false, message: 'Error creating transaction' });
  }
});

// Get transactions for specific account
app.get('/transactions/:accountNumber', (req, res) => {
  try {
    const { accountNumber } = req.params;
    const transactions = readTransactions();
    const accountTransactions = transactions.filter(
      t => t.senderAccount === accountNumber || t.receiverAccount === accountNumber
    );
    
    accountTransactions.sort((a, b) => new Date(b.dateTime) - new Date(a.dateTime));
    
    res.json(accountTransactions);
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error reading transactions' });
  }
});

// Get notifications for account
app.get('/notifications/:accountNumber', (req, res) => {
  try {
    const { accountNumber } = req.params;
    const notifications = readNotifications();
    const accountNotifications = notifications.filter(n => n.accountNumber === accountNumber);
    
    res.json(accountNotifications);
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error reading notifications' });
  }
});

// Get system statistics
app.get('/stats', (req, res) => {
  try {
    const accounts = readAccounts();
    const transactions = readTransactions();
    
    const totalAccounts = accounts.length;
    const activeAccounts = accounts.filter(a => a.status === 'approved').length;
    const pendingKYC = accounts.filter(a => a.kycStatus === 'pending').length;
    const totalBalance = accounts.reduce((sum, a) => sum + (parseFloat(a.balance) || 0), 0);
    const totalTransactions = transactions.length;
    
    res.json({
      totalAccounts,
      activeAccounts,
      pendingKYC,
      totalBalance,
      totalTransactions
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error reading stats' });
  }
});

// Initialize and start server
initializeDataFiles();

app.listen(PORT, () => {
  console.log('=================================');
  console.log('🏦 Global Bank Nigeria Backend');
  console.log('=================================');
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`Admin: http://localhost:${PORT}/admin/cover.html`);
  console.log(`Customer: http://localhost:${PORT}/customer/`);
  console.log('=================================');
  console.log('Default Admin Credentials:');
  console.log('Username: admin');
  console.log('Password: admin123');
  console.log('=================================');
});

module.exports = app;